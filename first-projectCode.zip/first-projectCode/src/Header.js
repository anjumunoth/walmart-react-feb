import React from "react";

import walLogo from "./walmartLogo.jpg";

// class component
class Header extends React.Component {
    render() {
        // return the virtual DOM
        return (
            <div>
                {/*  
                <img src="./images/walmartLogo2.jpg" alt="Walmart logo2" />*/}
                <div className="container-fluid">
                    <div className="row align-items-center bg-warning">
                        <img src={walLogo} alt="Walmart Logo" className="img-fluid col-6" />
                        <h1 className=" text-primary col-6 text-center"> Shopping Cart</h1>

                    </div>

                </div>
                
            </div>


        );
    }
}

export default Header;

