import React,{Component} from 'react';
import "./Footer.css"

class Footer extends Component
{
    render()
    {
        return (
            <h1 id="footerH1">Copyrights anju munoth@2022</h1>
        );
    }
}

export default Footer;