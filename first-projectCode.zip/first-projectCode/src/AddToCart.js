
import React, { Component } from 'react'

export default class AddToCart extends Component {
  render() {
      console.log("State"+this.state);
    return (
      <div>AddToCart</div>
    )
  }
}
