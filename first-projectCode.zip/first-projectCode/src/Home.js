import React from 'react'
import AddToCart from './AddToCart';

class Home extends React.Component
{
    constructor()
    {
        super();
        this.ctr=100;
        
        console.log("Home constructor called");
        this.state={showAddToCart:false}
        this.addToCartEventHandler=this.addToCartEventHandler.bind(this);//this --> component
    }
    addToCartEventHandler=function(selectedProduct){
        alert("Add to Cart clicked");
        alert("Show Add to Cart before change"+this.state.showAddToCart);
        alert("Ctr in addToCartEventHandler"+this.ctr);// this -->button scope; error
        alert("Selected ProductId"+selectedProduct.productId);
        //this.showAddToCart=true;

        //this.state.showAddToCart=true;// 2 problems : 1. render will not be called 2. not following immutability
        
        this.setState({showAddToCart:true});
        
        //alert("Show add to cart"+this.showAddToCart);
        // return a new virtual Dom with the changes
        // update the state;call the render again
        // render -- called implicitly -- lifecycle method
        // 

    }
    detailsEventHandler=(selectedProduct)=>{
        alert("Details clicked");
        alert("Ctr in detailsEventHandler"+this.ctr);// this -->lexical scope; 100
        alert("Selected ProductId"+selectedProduct.productId);
    }
    render()
    {
        var productsArr=[
            {productId:101,productName:"Apple Iphone",description:"Apple Iphone 13 pro max",price:3456789,quantity:4,imgUrl:"./images/iphone13.jpg"},
            {productId:102,productName:"Nokia 3310",description:"Nokia 3310 flagship model",price:6789,quantity:14,imgUrl:"./images/nokia.jpg"},
            {productId:103,productName:"One plus 9",description:"One plus 9 nord 1tb storage",price:61789,quantity:12,imgUrl:"./images/oneplus9.jpg"},
            {productId:104,productName:"Google pixel",description:"Google pixel 5",price:56789,quantity:7,imgUrl:"./images/pixel.jpg"},
          
            {productId:105,productName:"Samsung Fold3",description:"Best foldable mobile",price:156789,quantity:2,imgUrl:"./images/samsungFold3.jpg"}
        ];
        console.log("Home render method called");

        var cardArr=productsArr.map(item =>{
            return (
                <div className='card m-3 bg-warning text-primary' style={ {width:"18rem"} }>
                <img style={{height:"15rem"}} className='card-img-top img-fluid rounded mx-auto d-block' src={item.imgUrl} alt={item.productName} />
                <div className='card-body'>
                    <h1 className='card-title'>{item.productName}</h1>
                    <p className='card-text'>Price : Rs {item.price}</p>
                    <p className='card-text'>Quantity : {item.quantity}</p>
                    <input type="button" value="Add To Cart" className='btn btn-success' onClick={this.addToCartEventHandler.bind(this,item)} />
                    <input type="button" value="Details" className='btn btn-success' onClick={()=>{ this.detailsEventHandler(item)}} />
                </div>
            </div>
           
            );
        })
        return (

            <div className='container-fluid'>
                <div className='row'>
                    <h1 className='col-12'> Mobile phones</h1>
                </div>
                <div className='row'>
                    {cardArr}
                </div>
               
                {(this.state.showAddToCart === true) && <AddToCart></AddToCart>}

                {(this.state.showAddToCart === true) ? <AddToCart></AddToCart>: null}
            </div>
        );
    }
}

export default Home;

// dynamically generate some content -- cards
// number of elements in productsArr -- equivalent number of cards
// run a loop
// jsx -- no loops, no if else
// map function in ES6


// conditionally rendering 
// Logical and, ternary operator


/*
state -- local mutable data of the component
-- object which is initilaised in the constructor
-- modify the state -- call the setState();

setState() -- perform 2 tasks:
1. merge with the state;
2. call the render method implicitly


*/